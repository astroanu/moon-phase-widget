<?php
	// no direct access
	defined( '_JEXEC' ) or die( 'Restricted access' );
	require( JModuleHelper::getLayoutPath( 'mod_ajmoonphase' ) );
?>